// **** top_clock.v (顶层模块) *************
module top_clock(
    input clk_50m,      // 50MHz系统时钟
    input nCR,          // 异步复位键 (低电平有效)
    input AdjMinKey,    // 调分按键 (高电平有效)
    input AdjHrKey,     // 调时按键 (高电平有效)
    
    output [7:0] Sec,   // 秒显示 (BCD)
    output [7:0] Min,   // 分显示 (BCD)
    output [7:0] Hr     // 时显示 (BCD)
);

    wire clk_1hz;
    wire min_carry, hr_carry;
    wire min_en, hr_en;

    // 1. 例化 50MHz 降至 1Hz 的分频器
    divider U_Div (
        .clk_50m(clk_50m),
        .nCR(nCR),
        .clk_1hz(clk_1hz)
    );

    // 2. 秒计数器 (始终使能)
    counter60 U_Sec (
        .Cnt(Sec), 
        .nCR(nCR), 
        .EN(1'b1), 
        .CP(clk_1hz)
    );

    // 进位与校时控制逻辑：
    // 当秒计满59时，产生向分钟的正常进位
    assign min_carry = (Sec == 8'h59);
    
    // 分钟使能：正常秒进位 OR 按下调分按键
    assign min_en = min_carry | AdjMinKey; 

    // 3. 分钟计数器
    counter60 U_Min (
        .Cnt(Min), 
        .nCR(nCR), 
        .EN(min_en), 
        .CP(clk_1hz)
    );

    // 当分计满59 且秒也计满59 时，产生向小时的正常进位
    assign hr_carry = (Min == 8'h59) && min_carry;
    
    // 小时使能：正常分进位 OR 按下调时按键
    assign hr_en = hr_carry | AdjHrKey;

    // 4. 小时计数器 (24进制)
    counter24 U_Hr (
        .Cnt(Hr), 
        .nCR(nCR), 
        .EN(hr_en), 
        .CP(clk_1hz)
    );

endmodule